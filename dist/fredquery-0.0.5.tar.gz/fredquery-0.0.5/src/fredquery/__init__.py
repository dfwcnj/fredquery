# SPDX-FileCopyrightText: 2023-present Don Caldwell <dfwcnj@gmail.com>
#
# SPDX-License-Identifier: MIT
# https://fred.stlouisfed.org/docs/api/fred/

import fredquery.fredcategories
import fredquery.fredreleases
import fredquery.fredtags
import fredquery.fredsources

